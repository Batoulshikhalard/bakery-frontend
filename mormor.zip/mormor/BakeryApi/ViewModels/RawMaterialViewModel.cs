﻿namespace BakeryApi.ViewModels;
public class RawMaterialViewModel
{
    public int RawMaterialId { get; set; }
    public string? Name { get; set; }
    public string? Code { get; set; }
    public double PricePerKg { get; set; }
}
