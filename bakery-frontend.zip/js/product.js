import { getProducts, addProduct } from './api.js';

const list = document.getElementById("productList");
const form = document.getElementById("addProductForm");

async function loadProducts() {
  const products = await getProducts();
  list.innerHTML = "";
  products.forEach(p => {
    const li = document.createElement("li");
    li.textContent = `${p.name} - ${p.price} kr`;
    list.appendChild(li);
  });
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = form.name.value.trim();
  const price = parseFloat(form.price.value);
  if (!name || isNaN(price)) return alert("Invalid input");
  await addProduct({ name, price });
  form.reset();
  loadProducts();
});

loadProducts();
